package careerpilot.careerpilot_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareerpilotBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareerpilotBackendApplication.class, args);
	}

}
